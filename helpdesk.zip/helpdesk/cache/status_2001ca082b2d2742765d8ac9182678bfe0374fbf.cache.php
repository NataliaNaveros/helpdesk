<?php if (!defined('IN_SCRIPT')) {die();} $hesk_settings['statuses']=array (
  0 => 
  array (
    'name' => 'Nuevo',
    'class' => 'open',
  ),
  1 => 
  array (
    'name' => 'Esperando respuesta ',
    'class' => 'waitingreply',
  ),
  2 => 
  array (
    'name' => 'Respondido',
    'class' => 'replied',
  ),
  3 => 
  array (
    'name' => 'Resuelto',
    'class' => 'resolved',
  ),
  4 => 
  array (
    'name' => 'En progreso',
    'class' => 'inprogress',
  ),
  5 => 
  array (
    'name' => 'En espera',
    'class' => 'onhold',
  ),
);